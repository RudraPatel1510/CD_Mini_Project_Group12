/* Mini Compiler front-end: code editor, compile request, Output and Tokens tabs. */
(function () {
  "use strict";

  const PHASES = ["Lexer", "Parser", "Semantic", "ICG", "Optimizer", "Execution"];
  const LINE_HEIGHT = 20; // must match --code-line in style.css
  const EDITOR_PADDING = 12;
  const INDENT = "    ";

  const $ = (id) => document.getElementById(id);
  const code = $("code");
  const gutter = $("gutter");
  const highlights = $("highlights");
  const compileBtn = $("compileBtn");
  const sampleSelect = $("sampleSelect");

  const state = {
    result: null,
    marks: {},              // line number -> "error" | "warn"
    samples: {},            // option value -> code
    lineCount: 0,
  };

  // ---------------------------------------------------------------- helpers

  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function storage(key, value) {
    try {
      if (value === undefined) return localStorage.getItem(key);
      localStorage.setItem(key, value);
    } catch (e) { /* storage may be unavailable; that's fine */ }
    return null;
  }

  function emptyState(icon, title, message) {
    return `<div class="empty"><div class="empty-icon">${escapeHtml(icon)}</div>
      <strong>${escapeHtml(title)}</strong><div>${escapeHtml(message)}</div></div>`;
  }

  /** Message shown in a tab whose phase produced nothing. */
  function skippedState(result, what) {
    if (!result) return emptyState("▶", "Nothing compiled yet", "Write a program and press Compile (Ctrl+Enter).");
    if (result.failed_phase) {
      return emptyState("–", `No ${what}`, `Skipped: compilation stopped at the ${result.failed_phase} phase.`);
    }
    return emptyState("∅", `No ${what}`, "The program produced nothing here.");
  }

  // ----------------------------------------------------------------- editor

  function renderGutter() {
    const lines = code.value.split("\n").length;
    let html = "";
    for (let i = 1; i <= lines; i++) {
      const mark = state.marks[i];
      html += `<div${mark ? ` class="${mark}"` : ""}>${i}</div>`;
    }
    gutter.innerHTML = html;
    state.lineCount = lines;
    $("lineCount").textContent = `${lines} line${lines === 1 ? "" : "s"}`;
  }

  function renderLineMarks() {
    highlights.innerHTML = Object.entries(state.marks)
      .map(([line, kind]) =>
        `<div class="line-mark ${kind}" style="top:${EDITOR_PADDING + (line - 1) * LINE_HEIGHT}px"></div>`)
      .join("");
    renderGutter();
  }

  function syncScroll() {
    gutter.style.transform = `translateY(${-code.scrollTop}px)`;
    highlights.style.transform = `translate(${-code.scrollLeft}px, ${-code.scrollTop}px)`;
  }

  function updateCursor() {
    const before = code.value.slice(0, code.selectionStart);
    const line = before.split("\n").length;
    const col = before.length - before.lastIndexOf("\n");
    $("cursorPos").textContent = `Ln ${line}, Col ${col}`;
  }

  /** Insert text at the caret, keeping the browser's undo history when possible. */
  function insertText(text) {
    code.focus();
    const ok = document.execCommand && document.execCommand("insertText", false, text);
    if (!ok) {
      code.setRangeText(text, code.selectionStart, code.selectionEnd, "end");
      code.dispatchEvent(new Event("input"));
    }
  }

  function setCode(text) {
    code.value = text;
    code.scrollTop = 0;
    code.scrollLeft = 0;
    state.marks = {};
    renderLineMarks();
    syncScroll();
    storage("mc-code", text);
  }

  function goToLine(line) {
    const lines = code.value.split("\n");
    if (!line || line > lines.length) return;
    let start = 0;
    for (let i = 0; i < line - 1; i++) start += lines[i].length + 1;
    code.focus();
    code.setSelectionRange(start, start + lines[line - 1].length);
    code.scrollTop = Math.max(0, (line - 1) * LINE_HEIGHT - code.clientHeight / 3);
    updateCursor();
  }

  code.addEventListener("input", () => {
    if (Object.keys(state.marks).length) {
      state.marks = {};
      renderLineMarks();
    } else if (code.value.split("\n").length !== state.lineCount) {
      renderGutter();
    }
    updateCursor();
    storage("mc-code", code.value);
  });
  code.addEventListener("scroll", syncScroll);
  ["click", "keyup", "focus"].forEach((name) => code.addEventListener(name, updateCursor));

  code.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
      event.preventDefault();
      compile();
    } else if (event.key === "Tab" && !event.ctrlKey && !event.altKey) {
      event.preventDefault();
      insertText(INDENT);
    } else if (event.key === "Enter" && !event.shiftKey) {
      // Keep the current indentation; indent one more level after "{".
      event.preventDefault();
      const before = code.value.slice(0, code.selectionStart);
      const currentLine = before.slice(before.lastIndexOf("\n") + 1);
      let indent = currentLine.match(/^\s*/)[0];
      if (/\{\s*$/.test(currentLine)) indent += INDENT;
      insertText("\n" + indent);
    }
  });

  // ---------------------------------------------------------------- samples

  async function loadSamples() {
    try {
      const response = await fetch("/api/samples");
      const data = await response.json();
      data.groups.forEach((group, g) => {
        const optgroup = el("optgroup");
        optgroup.label = group.name;
        group.samples.forEach((sample, s) => {
          const key = `${g}:${s}`;
          state.samples[key] = sample.code;
          const option = el("option", "", sample.title);
          option.value = key;
          optgroup.appendChild(option);
        });
        sampleSelect.appendChild(optgroup);
      });
      return data.groups;
    } catch (e) {
      return [];
    }
  }

  sampleSelect.addEventListener("change", () => {
    const sample = state.samples[sampleSelect.value];
    if (sample === undefined) return;
    setCode(sample);
    compile();
  });

  $("clearBtn").addEventListener("click", () => {
    setCode("");
    sampleSelect.value = "";
    state.result = null;
    renderAll(null);
    code.focus();
  });

  // ---------------------------------------------------------------- compile

  async function compile() {
    compileBtn.disabled = true;
    renderPipeline(PHASES.map((name) => ({ name, status: "running" })));
    setStatus("Compiling…", "");
    let result;
    try {
      const response = await fetch("/api/compile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: code.value }),
      });
      result = await response.json();
    } catch (e) {
      result = {
        success: false,
        failed_phase: null,
        phases: PHASES.map((name) => ({ name, status: "skipped" })),
        errors: [{ phase: "Server", message: "could not reach the compiler server. Is app.py running?", line: null }],
        warnings: [],
      };
    }
    state.result = result;
    renderAll(result);
    compileBtn.disabled = false;
  }

  compileBtn.addEventListener("click", compile);

  // ------------------------------------------------------- render: overview

  function setStatus(text, kind) {
    const status = $("statusText");
    status.textContent = text;
    status.className = "status-text" + (kind ? " " + kind : "");
  }

  function renderPipeline(phases) {
    const errors = (state.result && state.result.errors) || [];
    $("pipeline").innerHTML = phases.map((phase) => {
      const err = errors.find((e) => e.phase === phase.name);
      const title = phase.status === "failed" && err ? ` title="${escapeHtml(err.text || err.message)}"` : "";
      return `<li><span class="phase ${phase.status}"${title}><span class="dot"></span>${phase.name}</span></li>`;
    }).join("");
  }

  function renderAll(result) {
    if (result) {
      renderPipeline(result.phases || []);
      if (result.success) setStatus(`✓ Compiled successfully in ${result.time_ms} ms`, "ok");
      else if (result.failed_phase) setStatus(`✗ Compilation failed at the ${result.failed_phase} phase`, "fail");
      else setStatus("✗ Request failed", "fail");
    } else {
      renderPipeline(PHASES.map((name) => ({ name, status: "idle" })));
      setStatus("Ready", "");
    }
    renderDiagnostics(result);
    renderOutput(result);
    renderTokens(result);
  }

  function renderDiagnostics(result) {
    const box = $("diagnostics");
    state.marks = {};
    if (!result) {
      box.innerHTML = "";
      renderLineMarks();
      return;
    }
    const errors = result.errors || [];
    const warnings = result.warnings || [];
    warnings.forEach((w) => { if (w.line) state.marks[w.line] = "warn"; });
    errors.forEach((e) => { if (e.line) state.marks[e.line] = "error"; });
    renderLineMarks();

    const item = (d, kind, icon) => `
      <div class="diag ${kind}" data-line="${d.line || ""}">
        <span class="diag-icon">${icon}</span>
        <span class="diag-phase">${escapeHtml(d.phase)}</span>
        <span>${d.line ? `<span class="diag-loc">Line ${d.line}${d.column ? ", Col " + d.column : ""}</span>` : ""}<span class="diag-msg">${escapeHtml(d.message)}</span></span>
      </div>`;

    let html = `<div class="diag-header">Problems
      <span class="badge">${errors.length} error${errors.length === 1 ? "" : "s"}</span>
      <span class="badge">${warnings.length} warning${warnings.length === 1 ? "" : "s"}</span></div>`;
    html += errors.map((e) => item(e, "error", "✗")).join("");
    html += warnings.map((w) => item(w, "warning", "!")).join("");
    if (!errors.length && !warnings.length) {
      html += `<div class="diag ok"><span class="diag-icon">✓</span><span class="diag-msg">No problems found.</span></div>`;
    }
    box.innerHTML = html;
    box.querySelectorAll(".diag[data-line]").forEach((node) => {
      const line = Number(node.dataset.line);
      if (line) node.addEventListener("click", () => goToLine(line));
    });
  }

  // --------------------------------------------------------- render: output

  function renderOutput(result) {
    const pane = $("pane-output");
    if (!result) {
      pane.innerHTML = skippedState(null);
      return;
    }
    let html = '<div class="output-wrap">';
    if (result.success) {
      html += `<div class="result-banner ok">✓ Program compiled and ran successfully <span>· ${result.time_ms} ms</span></div>`;
    } else {
      const err = (result.errors || [])[0];
      const where = result.failed_phase ? `${result.failed_phase} phase` : "request";
      html += `<div class="result-banner fail">✗ Failed at the ${escapeHtml(where)}
        <span>· ${escapeHtml(err ? err.text || err.message : "unknown error")}</span></div>`;
    }

    const output = result.output || [];
    const ran = result.success || result.failed_phase === "Execution";
    html += `<div class="console"><div class="console-head"><span>program output</span>
      <span>${ran ? `${output.length} line${output.length === 1 ? "" : "s"}` : "not executed"}</span></div>
      <div class="console-body">`;
    if (!ran) {
      html += `<div class="console-empty">The program did not run because compilation stopped early.</div>`;
    } else if (!output.length) {
      html += `<div class="console-empty">(no output)</div>`;
    } else {
      html += output.map((line, i) =>
        `<div class="console-line"><span class="n">${i + 1}</span><span class="v">${escapeHtml(line)}</span></div>`).join("");
    }
    if (result.failed_phase === "Execution") {
      const err = result.errors[0];
      html += `<div class="console-line"><span class="n">!</span><span class="v" style="color:var(--red)">runtime error: ${escapeHtml(err.text)}</span></div>`;
    }
    html += "</div></div></div>";
    pane.innerHTML = html;
  }

  // --------------------------------------------------------- render: tokens

  function renderTokens(result) {
    const pane = $("pane-tokens");
    const tokens = (result && result.tokens) || [];
    $("tokenCount").textContent = tokens.length || "";
    if (!tokens.length) {
      pane.innerHTML = skippedState(result, "tokens");
      return;
    }
    const rows = tokens.map((t, i) => `<tr>
        <td class="num">${i + 1}</td>
        <td><span class="tok ${t.type}">${t.type}</span></td>
        <td class="mono">${t.type === "EOF" ? '<span class="no">end of input</span>' : escapeHtml(t.value)}</td>
        <td class="num">${t.line}</td>
        <td class="num">${t.column}</td></tr>`).join("");
    const lexFailed = result.failed_phase === "Lexer";
    pane.innerHTML = `<div class="pane-toolbar"><strong>${tokens.length}</strong> tokens
        ${lexFailed ? '<span style="color:var(--red)">· invalid characters were skipped</span>' : ""}</div>
      <table class="data"><thead><tr><th>#</th><th>Type</th><th>Lexeme</th><th>Line</th><th>Col</th></tr></thead>
      <tbody>${rows}</tbody></table>`;
  }

  // ------------------------------------------------------------ tabs, theme

  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t === tab));
      document.querySelectorAll(".pane").forEach((pane) =>
        pane.classList.toggle("active", pane.id === "pane-" + tab.dataset.tab));
    });
  });

  $("themeToggle").addEventListener("click", () => {
    const root = document.documentElement;
    const next = root.getAttribute("data-theme") === "light" ? "dark" : "light";
    root.setAttribute("data-theme", next);
    storage("mc-theme", next);
  });

  // ------------------------------------------------------------------ start

  /** Restore the last code (or open the grade calculator sample) and compile it. */
  async function start() {
    renderAll(null);
    const groups = await loadSamples();
    const savedCode = storage("mc-code");
    if (savedCode !== null && savedCode.trim()) {
      setCode(savedCode);
    } else if (groups.length && groups[0].samples.length) {
      const preferred = groups[0].samples.findIndex((s) => /grade/i.test(s.file));
      const index = preferred >= 0 ? preferred : 0;
      sampleSelect.value = `0:${index}`;
      setCode(groups[0].samples[index].code);
    }
    updateCursor();
    if (code.value.trim()) compile();
  }

  start();
})();
