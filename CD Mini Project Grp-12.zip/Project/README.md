# Mini Compiler for If-Else Statements

A small compiler written in Python for a Compiler Design course project. It compiles
a simple C-like language built around `if` / `else` statements, running it through the
classic compiler phases, and then runs the program. You write code in a web page,
click **Compile**, and see the output, the tokens, and which phase passed or failed.

```
source code ─► Lexer ─► Parser ─► Semantic ─► ICG ─► Optimizer ─► Execution ─► output
              tokens     AST     symbol table  three-address code    run the code
```

## How to run

Requires **Python 3.8+**. Flask is the only dependency.

```bash
pip install -r requirements.txt
python app.py
```

Then open **http://localhost:5000**.

- Write code on the left, or pick a program from **Load sample…**.
- Click **Compile** or press **Ctrl + Enter**.
- **Output** shows what the program printed. **Tokens** shows the lexer's token table.
- The bar at the bottom shows each phase: green = passed, red = failed, grey = skipped.
- Errors (red) and warnings (yellow) show the phase and line number, and the line is highlighted in the editor.

### Command line (shows every phase)

The web page shows the output and tokens. To see the other phases, use the CLI:

```bash
python cli.py samples/08_grade_calculator.txt          # program output only
python cli.py samples/08_grade_calculator.txt --all    # every phase
```

Flags: `--tokens`, `--ast`, `--symbols`, `--tac`, `--opt`, `--all`.

### Tests

```bash
python -m unittest discover -s tests -v
```

86 tests cover every phase, every sample program, and the web server.

## The language

```c
// single-line comment
int marks = 72;              // int or float variables
float average = 81.5;
int grade;                   // a variable without a value starts at 0

if (marks >= 90) {           // if / else if / else
    grade = 1;
} else if (marks >= 75 && average > 80.0) {
    grade = 2;
} else {
    grade = 3;
}

print("Marks:", marks, "Grade:", grade);   // text and values, separated by commas
```

| Feature     | Supported                                                            |
|-------------|----------------------------------------------------------------------|
| Types       | `int`, `float`                                                       |
| Arithmetic  | `+ - * / %` (`int / int` drops the decimal part, as in C)            |
| Comparison  | `< > <= >= == !=`                                                    |
| Logical     | `&&` (and), `\|\|` (or), `!` (not), with short-circuit evaluation    |
| Statements  | declaration, assignment, `if`, `if-else`, `else if`, nested if, `{ }` blocks, `print` |
| Output      | `print(...)` with text in `"quotes"` and values, separated by commas |

- Operator precedence, lowest to highest: `||`, `&&`, `== !=`, `< > <= >=`, `+ -`, `* / %`, unary `! -`.
- An `else` always belongs to the nearest `if` (the "dangling else" rule).
- Each `{ }` block has its own scope, so an inner block can declare its own variable with the same name.
- Text can only be used inside `print`. There are no string variables.

### Grammar (BNF)

```
<program>     ::= { <statement> } EOF
<statement>   ::= <declaration> | <assignment> | <if_stmt> | <print_stmt> | <block>
<declaration> ::= ("int" | "float") IDENTIFIER [ "=" <expression> ] ";"
<assignment>  ::= IDENTIFIER "=" <expression> ";"
<if_stmt>     ::= "if" "(" <expression> ")" <statement> [ "else" <statement> ]
<print_stmt>  ::= "print" "(" [ <print_arg> { "," <print_arg> } ] ")" ";"
<print_arg>   ::= STRING_LITERAL | <expression>
<block>       ::= "{" { <statement> } "}"
<expression>  ::= <logic_or>
<logic_or>    ::= <logic_and> { "||" <logic_and> }
<logic_and>   ::= <equality> { "&&" <equality> }
<equality>    ::= <relational> { ("==" | "!=") <relational> }
<relational>  ::= <additive> { ("<" | ">" | "<=" | ">=") <additive> }
<additive>    ::= <term> { ("+" | "-") <term> }
<term>        ::= <unary> { ("*" | "/" | "%") <unary> }
<unary>       ::= ("!" | "-" | "+") <unary> | <primary>
<primary>     ::= INT_LITERAL | FLOAT_LITERAL | IDENTIFIER | "(" <expression> ")"
```

## How the compiler works

Each phase is a separate module in the `compiler/` folder. `compiler/pipeline.py` runs them
in order. If a phase finds an error, the later phases are skipped.

The walkthrough below follows this program through every phase
(produced with `python cli.py program.txt --all`):

```c
int marks = 72;
if (marks >= 40) {
    print("Pass");
} else {
    print("Fail");
}
```

### 1. Lexical analysis: `lexer.py`

Reads the text character by character and groups it into **tokens**. Each token has a
type, a value, and a line/column position. Spaces and comments are skipped.

```
1:1   KEYWORD      int          2:1   KEYWORD      if          2:11  REL_OP          >=
1:5   IDENTIFIER   marks        2:4   LPAREN       (           2:14  INT_LITERAL     40
1:11  ASSIGN       =            2:5   IDENTIFIER   marks       3:11  STRING_LITERAL  "Pass"   ...
```

Errors found here: invalid characters (`@`, `$`), malformed numbers (`12abc`), and a string
missing its closing quote.

### 2. Syntax analysis: `parser.py` and `ast_nodes.py`

A hand-written **recursive descent parser**: one function per grammar rule. It checks that
the tokens follow the grammar and builds an **Abstract Syntax Tree (AST)**.

```
Program
  Declaration int marks
    value: Literal 72
  If if-else
    condition: BinaryOp >=
      left: Identifier marks
      right: Literal 40
    then: Block → Print "Pass"
    else: Block → Print "Fail"
```

Errors found here: missing `;`, an unclosed `{`, `else` without `if`, and so on, for example
`Line 4: expected ';' after expression`.

### 3. Semantic analysis: `semantic.py`

Walks the AST with a **symbol table** that has one scope per `{ }` block.

| Name  | Type | Scope  | Line | Uses |
|-------|------|--------|------|------|
| marks | int  | global | 1    | 1    |

- **Errors:** undeclared variable, the same variable declared twice in one scope, `%` used on a float.
- **Warnings:** float value stored in an int (it gets truncated), unused variable, variable
  used before it gets a value, comparing floats with `==`, division by the literal `0`.
- It also works out the type (`int` / `float`) of every expression.

### 4. Intermediate code generation: `icg.py`

Turns the AST into **three-address code (TAC)**: simple instructions with at most one operator.
Conditions become `if … goto` jumps to labels.

```
    marks = 72
    if marks >= 40 goto L1
    goto L2
L1:
    print "Pass"
    goto L3
L2:
    print "Fail"
L3:
```

`&&` and `||` are compiled with **short-circuit evaluation**: in `a && b`, `b` is only
evaluated when `a` is true. Complex expressions use temporaries, so `x = a + b * c`
becomes `t1 = b * c` then `x = a + t1`.

### 5. Optimization: `optimizer.py`

Improves the TAC without changing what the program does:

- **Constant propagation:** `marks` is known to be 72, so `marks >= 40` becomes `72 >= 40`.
- **Constant folding:** `72 >= 40` is computed at compile time and becomes `1` (true).
- **Dead-branch elimination:** the condition is always true, so the `else` branch is removed.
- **Clean-up:** removes unreachable code, useless jumps, unused labels, and unused temporaries.

```
    marks = 72
    print "Pass"
```

### 6. Execution: `executor.py`

A small interpreter runs the optimized TAC one instruction at a time and collects what the
program prints:

```
Pass
```

Errors found here: division by zero, reported with its line number.

## Project structure

```
Project/
├── app.py              Flask web server: python app.py → http://localhost:5000
├── cli.py              Command line: shows the result of every phase
├── requirements.txt    Flask
├── compiler/
│   ├── __init__.py     exports compile_source()
│   ├── pipeline.py     compile_source(): runs all phases in order
│   ├── lexer.py        1. lexical analysis    → tokens
│   ├── parser.py       2. syntax analysis     → AST  (grammar written at the top)
│   ├── ast_nodes.py       AST node classes
│   ├── semantic.py     3. semantic analysis   → symbol table, type checks
│   ├── icg.py          4. intermediate code   → three-address code
│   ├── tac.py             three-address instruction format and arithmetic rules
│   ├── optimizer.py    5. optimization        → shorter three-address code
│   ├── executor.py     6. execution           → program output
│   └── errors.py          error and warning classes
├── templates/
│   └── index.html      the web page
├── static/
│   ├── css/style.css   page styles (dark and light theme)
│   └── js/app.js       editor, Compile button, Output and Tokens tabs
├── samples/            22 example programs
│   └── errors/         9 programs that each show a different error
└── tests/
    └── test_compiler.py
```

`compile_source(code)` returns one dictionary with `success`, `failed_phase`, `phases`
(the status of each phase), `tokens`, `ast`, `symbol_table`, `tac`, `optimized_tac`,
`output`, `errors`, `warnings` and `time_ms`. The web page and the CLI both use it.

## Sample programs

**Valid:** simple if · if-else (even/odd) · else-if ladder · nested if-else (leap year) ·
logical operators · float comparison (BMI) · constant folding · grade calculator ·
largest of three · dangling else & scopes · type conversion · positive/negative/zero ·
triangle type · electricity bill · point quadrant · simple calculator · divisibility check ·
discount calculator · time-of-day greeting · income tax · access control · safe division.

**Errors:** invalid character · missing semicolon · unmatched brace · undeclared variable ·
redeclaration · `%` on a float · `else` without `if` · division by zero · unterminated string.
