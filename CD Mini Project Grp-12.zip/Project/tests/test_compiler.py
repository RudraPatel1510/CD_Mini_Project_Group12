"""
Unit tests for every compiler phase, the full pipeline, the sample programs
and the Flask endpoints.

Run from the project folder:
    python -m unittest discover -s tests -v
"""

import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from compiler import compile_source                              # noqa: E402
from compiler.ast_nodes import BinaryOp, Block, If, Literal, StringLiteral, UnaryOp, VarDecl  # noqa: E402
from compiler.errors import CompilerError                        # noqa: E402
from compiler.executor import run_tac                            # noqa: E402
from compiler.icg import generate                                # noqa: E402
from compiler.lexer import string_value, tokenize                 # noqa: E402
from compiler.optimizer import optimize                          # noqa: E402
from compiler.parser import parse                                # noqa: E402
from compiler.semantic import analyze                            # noqa: E402
from compiler.tac import Instr                                   # noqa: E402

SAMPLES_DIR = os.path.join(ROOT, "samples")


def front_end(source):
    """Lex + parse + analyze; returns (program, symbols, errors, warnings)."""
    tokens, lex_errors = tokenize(source)
    assert not lex_errors, lex_errors
    program = parse(tokens)
    symbols, errors, warnings = analyze(program)
    return program, symbols, errors, warnings


def tac_for(source):
    program, _, errors, _ = front_end(source)
    assert not errors, errors
    return generate(program)


def tac_text(code):
    return [str(instr) for instr in code]


def run(source):
    result = compile_source(source)
    return result["output"]


# ----------------------------------------------------------------------------- 1

class TestLexer(unittest.TestCase):
    def types(self, source):
        tokens, errors = tokenize(source)
        self.assertEqual(errors, [])
        return [t.type for t in tokens]

    def test_declaration_tokens(self):
        tokens, _ = tokenize("int x = 10;")
        self.assertEqual([(t.type, t.value) for t in tokens], [
            ("KEYWORD", "int"), ("IDENTIFIER", "x"), ("ASSIGN", "="),
            ("INT_LITERAL", "10"), ("SEMICOLON", ";"), ("EOF", "")])

    def test_float_literal(self):
        tokens, _ = tokenize("2.5")
        self.assertEqual((tokens[0].type, tokens[0].value), ("FLOAT_LITERAL", "2.5"))

    def test_two_character_operators(self):
        tokens, _ = tokenize("<= >= == != && || < > !")
        self.assertEqual([t.value for t in tokens[:-1]], ["<=", ">=", "==", "!=", "&&", "||", "<", ">", "!"])
        self.assertEqual(tokens[4].type, "LOGICAL_OP")
        self.assertEqual(tokens[0].type, "REL_OP")

    def test_keywords_vs_identifiers(self):
        tokens, _ = tokenize("if else print iffy _x1")
        self.assertEqual([t.type for t in tokens[:-1]],
                         ["KEYWORD", "KEYWORD", "KEYWORD", "IDENTIFIER", "IDENTIFIER"])

    def test_line_and_column(self):
        tokens, _ = tokenize("int a;\n  a = 1;")
        a_token = tokens[3]
        self.assertEqual((a_token.value, a_token.line, a_token.column), ("a", 2, 3))

    def test_comments_are_skipped(self):
        self.assertEqual(self.types("// hello\nx = 1; // trailing"),
                         ["IDENTIFIER", "ASSIGN", "INT_LITERAL", "SEMICOLON", "EOF"])

    def test_invalid_character_reported_with_position(self):
        _, errors = tokenize("int a = 5;\nint b = 3 @ 2;")
        self.assertEqual(len(errors), 1)
        self.assertEqual((errors[0].line, errors[0].column), (2, 11))
        self.assertIn("'@'", errors[0].message)

    def test_single_ampersand_hint(self):
        _, errors = tokenize("a & b")
        self.assertIn("did you mean '&&'", errors[0].message)

    def test_malformed_numbers(self):
        _, errors = tokenize("5. 12abc")
        self.assertEqual(len(errors), 2)

    def test_string_literal_and_comma(self):
        tokens, errors = tokenize('print("Total:", x);')
        self.assertEqual(errors, [])
        self.assertEqual([(t.type, t.value) for t in tokens[2:5]],
                         [("STRING_LITERAL", '"Total:"'), ("COMMA", ","), ("IDENTIFIER", "x")])

    def test_string_escapes(self):
        tokens, _ = tokenize(r'"a\tb\n\"c\""')
        self.assertEqual(string_value(tokens[0].value), 'a\tb\n"c"')

    def test_unterminated_string(self):
        _, errors = tokenize('print("oops);\nx = 1;')
        self.assertEqual(len(errors), 1)
        self.assertIn("unterminated string", errors[0].message)
        self.assertEqual((errors[0].line, errors[0].column), (1, 7))

    def test_unknown_escape(self):
        _, errors = tokenize(r'"bad \q"')
        self.assertEqual(len(errors), 1)
        self.assertIn("unknown escape", errors[0].message)


# ----------------------------------------------------------------------------- 2

class TestParser(unittest.TestCase):
    def parse_source(self, source):
        tokens, _ = tokenize(source)
        return parse(tokens)

    def parse_error(self, source):
        with self.assertRaises(CompilerError) as context:
            self.parse_source(source)
        return context.exception

    def expression(self, source):
        return self.parse_source(f"x = {source};").statements[0].value

    def test_arithmetic_precedence(self):
        expr = self.expression("1 + 2 * 3")
        self.assertEqual(expr.op, "+")
        self.assertEqual(expr.right.op, "*")

    def test_parentheses(self):
        expr = self.expression("(1 + 2) * 3")
        self.assertEqual(expr.op, "*")
        self.assertEqual(expr.left.op, "+")

    def test_left_associativity(self):
        expr = self.expression("10 - 4 - 3")
        self.assertEqual(expr.left.op, "-")
        self.assertIsInstance(expr.right, Literal)

    def test_logical_precedence(self):
        expr = self.expression("a || b && c")
        self.assertEqual(expr.op, "||")
        self.assertEqual(expr.right.op, "&&")

    def test_relational_binds_tighter_than_logical(self):
        expr = self.expression("a < b && c != d")
        self.assertEqual(expr.op, "&&")
        self.assertEqual((expr.left.op, expr.right.op), ("<", "!="))

    def test_unary_operators(self):
        expr = self.expression("!-a")
        self.assertIsInstance(expr, UnaryOp)
        self.assertEqual(expr.op, "!")
        self.assertEqual(expr.operand.op, "-")

    def test_if_else_chain(self):
        program = self.parse_source("if (a) x = 1; else if (b) x = 2; else x = 3;")
        outer = program.statements[0]
        self.assertIsInstance(outer.else_branch, If)
        self.assertIsNotNone(outer.else_branch.else_branch)

    def test_dangling_else_binds_to_nearest_if(self):
        program = self.parse_source("if (a) if (b) x = 1; else x = 2;")
        outer = program.statements[0]
        self.assertIsNone(outer.else_branch)
        self.assertIsNotNone(outer.then_branch.else_branch)

    def test_blocks_and_declarations(self):
        program = self.parse_source("{ int a = 1; float b; }")
        block = program.statements[0]
        self.assertIsInstance(block, Block)
        self.assertIsInstance(block.statements[1], VarDecl)
        self.assertIsNone(block.statements[1].initializer)

    def test_missing_semicolon_reported_on_statement_line(self):
        error = self.parse_error("int x = 1;\nx = x + 1\nprint(x);")
        self.assertEqual(error.line, 2)
        self.assertEqual(error.message, "expected ';' after expression")
        self.assertEqual(str(error), "Line 2: expected ';' after expression")

    def test_unmatched_open_brace(self):
        error = self.parse_error("if (a) {\n x = 1;\n")
        self.assertEqual(error.line, 1)
        self.assertIn("unmatched '{'", error.message)

    def test_unexpected_close_brace(self):
        self.assertIn("no matching '{'", self.parse_error("x = 1; }").message)

    def test_else_without_if(self):
        self.assertIn("'else' without", self.parse_error("x = 1;\nelse x = 2;").message)

    def test_missing_paren_with_assignment_hint(self):
        error = self.parse_error("if (x = 1) print(x);")
        self.assertIn("did you mean '=='", error.message)

    def test_missing_expression(self):
        self.assertIn("expected an expression", self.parse_error("x = ;").message)

    def test_print_with_several_arguments(self):
        statement = self.parse_source('print("x is", x, "and y is", y + 1);').statements[0]
        self.assertEqual(len(statement.arguments), 4)
        self.assertIsInstance(statement.arguments[0], StringLiteral)
        self.assertEqual(statement.arguments[0].value, "x is")
        self.assertIsInstance(statement.arguments[3], BinaryOp)

    def test_empty_print(self):
        self.assertEqual(self.parse_source("print();").statements[0].arguments, [])

    def test_text_outside_print_is_an_error(self):
        self.assertIn("only be used as an argument of print", self.parse_error('int x = "hi";').message)

    def test_text_joined_with_plus_gives_a_hint(self):
        self.assertIn("separate the values with commas", self.parse_error('print("Total: " + x);').message)

    def test_ast_to_dict(self):
        data = self.parse_source("if (a > 1) print(a);").to_dict()
        if_node = data["children"][0]
        self.assertEqual(if_node["type"], "If")
        self.assertEqual([c["role"] for c in if_node["children"]], ["condition", "then"])
        self.assertEqual(if_node["children"][0]["detail"], ">")


# ----------------------------------------------------------------------------- 4

class TestSemantic(unittest.TestCase):
    def messages(self, items):
        return [d.message for d in items]

    def test_valid_program_has_no_errors(self):
        _, symbols, errors, _ = front_end("int a = 1; float b = a; if (a < b) { print(a); }")
        self.assertEqual(errors, [])
        self.assertEqual([(s.name, s.var_type) for s in symbols], [("a", "int"), ("b", "float")])

    def test_undeclared_variable(self):
        _, _, errors, _ = front_end("x = 5;")
        self.assertEqual(self.messages(errors), ["undeclared variable 'x'"])

    def test_redeclaration_in_same_scope(self):
        _, _, errors, _ = front_end("int a = 1;\nint a = 2;\nprint(a);")
        self.assertEqual(len(errors), 1)
        self.assertIn("redeclaration of 'a'", errors[0].message)
        self.assertEqual(errors[0].line, 2)

    def test_shadowing_in_inner_block_is_allowed(self):
        _, symbols, errors, _ = front_end("int a = 1; { int a = 2; print(a); } print(a);")
        self.assertEqual(errors, [])
        self.assertEqual([(s.scope, s.depth) for s in symbols], [("global", 0), ("block 1", 1)])

    def test_variable_out_of_scope(self):
        _, _, errors, _ = front_end("{ int a = 1; } print(a);")
        self.assertEqual(self.messages(errors), ["undeclared variable 'a'"])

    def test_float_to_int_warning(self):
        _, _, errors, warnings = front_end("int a = 2.5; print(a);")
        self.assertEqual(errors, [])
        self.assertTrue(any("from 'float' to 'int'" in w.message for w in warnings))

    def test_int_to_float_widening_is_silent(self):
        _, _, _, warnings = front_end("float f = 3; print(f);")
        self.assertEqual(warnings, [])

    def test_modulo_on_float_is_an_error(self):
        _, _, errors, _ = front_end("float f = 2.5; print(f % 2);")
        self.assertIn("'%' requires int operands", errors[0].message)

    def test_expression_types_are_annotated(self):
        program, _, _, _ = front_end("int a = 1; float b = 2.0; print(a + b); print(a < b);")
        self.assertEqual(program.statements[2].arguments[0].dtype, "float")
        self.assertEqual(program.statements[3].arguments[0].dtype, "int")

    def test_undeclared_variable_inside_print_arguments(self):
        _, _, errors, _ = front_end('print("value:", missing);')
        self.assertEqual(self.messages(errors), ["undeclared variable 'missing'"])

    def test_unused_and_uninitialized_warnings(self):
        _, _, _, warnings = front_end("int unused = 1; int later; print(later);")
        text = " ".join(self.messages(warnings))
        self.assertIn("'unused' is declared but never used", text)
        self.assertIn("'later' is used before it is assigned", text)


# ----------------------------------------------------------------------------- 5

class TestICG(unittest.TestCase):
    def test_arithmetic_uses_temporaries(self):
        code, temps = tac_for("int a = 1; int b = 2; int c = a + b * 3; print(c);")
        self.assertEqual(tac_text(code), ["a = 1", "b = 2", "t1 = b * 3", "c = a + t1", "print c"])
        self.assertEqual(temps, {"t1"})

    def test_if_else_layout(self):
        code, _ = tac_for("int a = 1; if (a < 5) print(1); else print(2);")
        self.assertEqual(tac_text(code), [
            "a = 1", "if a < 5 goto L1", "goto L2",
            "L1:", "print 1", "goto L3",
            "L2:", "print 2", "L3:"])

    def test_short_circuit_and(self):
        code, _ = tac_for("int a = 1; int b = 2; if (a > 0 && b > 0) print(1);")
        self.assertEqual(tac_text(code)[2:], [
            "if a > 0 goto L3", "goto L2", "L3:",
            "if b > 0 goto L1", "goto L2", "L1:", "print 1", "L2:"])

    def test_short_circuit_or(self):
        code, _ = tac_for("int a = 1; int b = 2; if (a > 0 || b > 0) print(1);")
        text = tac_text(code)
        # a true jumps straight to the then-branch, skipping the b test
        self.assertEqual(text[2], "if a > 0 goto L1")
        self.assertEqual(text[3], "goto L3")

    def test_not_swaps_targets(self):
        code, _ = tac_for("int a = 1; if (!(a == 1)) print(1);")
        self.assertEqual(tac_text(code)[1:3], ["if a == 1 goto L2", "goto L1"])

    def test_float_to_int_cast(self):
        code, _ = tac_for("float f = 2.5; int a = f * 2; print(a);")
        self.assertIn("a = (int) t1", tac_text(code))

    def test_shadowed_variables_get_unique_names(self):
        code, _ = tac_for("int x = 1; { int x = 2; print(x); } print(x);")
        self.assertEqual(tac_text(code), ["x = 1", "x_1 = 2", "print x_1", "print x"])

    def test_temporaries_avoid_user_names(self):
        code, temps = tac_for("int t1 = 4; int y = t1 * 2 + 1; print(y);")
        self.assertNotIn("t1", temps)

    def test_print_with_text_uses_write_then_print(self):
        code, _ = tac_for('int a = 1; print("a is", a, "now");')
        self.assertEqual(tac_text(code), ["a = 1", 'write "a is"', "write a", 'print "now"'])

    def test_logical_value_context(self):
        code, _ = tac_for("int a = 1; int b = a > 0 && a < 5; print(b);")
        text = tac_text(code)
        self.assertIn("b = 1", text)
        self.assertIn("b = 0", text)


# ----------------------------------------------------------------------------- 6

class TestOptimizer(unittest.TestCase):
    def optimized(self, source):
        code, temps = tac_for(source)
        return tac_text(optimize(code, temps))

    def test_constant_folding(self):
        self.assertEqual(self.optimized("int a = 2 + 3 * 4; print(a);"), ["a = 14", "print 14"])

    def test_constant_propagation(self):
        self.assertEqual(self.optimized("int a = 5; int b = a * 2; print(b);"), ["a = 5", "b = 10", "print 10"])

    def test_dead_branch_elimination(self):
        text = self.optimized("int a = 10; if (a > 5) print(1); else print(2);")
        self.assertEqual(text, ["a = 10", "print 1"])

    def test_always_false_if_removed(self):
        self.assertEqual(self.optimized("int a = 0; if (a == 1) print(1); print(2);"), ["a = 0", "print 2"])

    def test_int_division_folds_like_c(self):
        text = self.optimized("int a = -7 / 2; int b = -7 % 2; print(a); print(b);")
        self.assertEqual(text[:2], ["a = -3", "b = -1"])

    def test_division_by_zero_not_folded(self):
        self.assertIn("t1 = 5 / 0", self.optimized("int z = 0; print(5 / z);"))

    def test_propagation_stops_at_labels(self):
        # x is 1 or 2 depending on the unknown c, so "print x" must stay.
        code = [
            Instr("copy", result="x", arg1=1),
            Instr("if", arg1="c", label="L1"),
            Instr("copy", result="x", arg1=2),
            Instr("label", label="L1"),
            Instr("print", arg1="x"),
        ]
        self.assertEqual(tac_text(optimize(code))[-1], "print x")

    def test_original_code_is_unchanged(self):
        code, temps = tac_for("int a = 2 + 3; print(a);")
        optimize(code, temps)
        self.assertEqual(tac_text(code), ["a = 2 + 3", "print a"])


# ----------------------------------------------------------------------------- 7

class TestExecutor(unittest.TestCase):
    def test_runs_unoptimized_and_optimized_code_identically(self):
        with open(os.path.join(SAMPLES_DIR, "08_grade_calculator.txt"), encoding="utf-8") as handle:
            source = handle.read()
        code, temps = tac_for(source)
        plain, _ = run_tac(code)
        fast, _ = run_tac(optimize(code, temps))
        self.assertEqual(plain, fast)

    def test_integer_and_float_division(self):
        self.assertEqual(run("int a = 7; float b = 7; print(a / 2); print(b / 2);"), ["3", "3.5"])

    def test_print_text_and_values(self):
        source = 'int g = 2; float avg = 83.5;\nprint("Grade:", g);\nprint("Average", avg, "marks");\nprint();'
        self.assertEqual(run(source), ["Grade: 2", "Average 83.5 marks", ""])

    def test_newline_escape_splits_output_lines(self):
        self.assertEqual(run(r'print("first\nsecond", 3);'), ["first", "second 3"])

    def test_float_formatting(self):
        self.assertEqual(run("float f = 5; print(f); print(0.1 + 0.2);"), ["5.0", "0.3"])

    def test_cast_truncates(self):
        self.assertEqual(run("float f = -2.9; int a = f; print(a);"), ["-2"])

    def test_nested_if_else(self):
        source = "int a = 3; int b = 9;\nif (a > b) print(a); else { if (b > 5) print(b); else print(0); }"
        self.assertEqual(run(source), ["9"])

    def test_short_circuit_avoids_division_by_zero(self):
        self.assertEqual(run("int z = 0; if (z != 0 && 10 / z > 1) print(1); else print(2);"), ["2"])

    def test_runtime_division_by_zero(self):
        code, _ = tac_for("int z = 0;\nprint(1);\nprint(5 / z);")
        output, error = run_tac(code)
        self.assertEqual(output, ["1"])
        self.assertEqual((error.phase, error.message, error.line), ("Execution", "division by zero", 3))


# ----------------------------------------------------------------------------- pipeline

class TestCompileSource(unittest.TestCase):
    def test_successful_result_shape(self):
        result = compile_source("int a = 1; if (a > 0) print(a);")
        self.assertTrue(result["success"])
        self.assertIsNone(result["failed_phase"])
        self.assertEqual([p["status"] for p in result["phases"]], ["passed"] * 6)
        self.assertEqual(set(result), {"success", "failed_phase", "phases", "tokens", "ast", "symbol_table",
                                       "tac", "optimized_tac", "output", "errors", "warnings", "time_ms"})
        self.assertEqual(result["output"], ["1"])

    def test_failure_keeps_earlier_results_and_skips_later_phases(self):
        result = compile_source("int a = 1;\nb = a;")
        self.assertEqual(result["failed_phase"], "Semantic")
        statuses = {p["name"]: p["status"] for p in result["phases"]}
        self.assertEqual(statuses, {"Lexer": "passed", "Parser": "passed", "Semantic": "failed",
                                    "ICG": "skipped", "Optimizer": "skipped", "Execution": "skipped"})
        self.assertTrue(result["tokens"])
        self.assertIsNotNone(result["ast"])
        self.assertEqual(result["tac"], [])
        self.assertEqual(result["errors"][0]["line"], 2)

    def test_lexer_failure(self):
        result = compile_source("int a = $;")
        self.assertEqual(result["failed_phase"], "Lexer")
        self.assertEqual(result["errors"][0]["phase"], "Lexer")

    def test_tac_and_optimized_tac_are_returned_as_text(self):
        result = compile_source("int a = 2 * 3; if (a > 1) print(a); else print(0);")
        self.assertEqual(result["tac"][:2], ["a = 2 * 3", "if a > 1 goto L1"])
        self.assertEqual(result["optimized_tac"], ["a = 6", "print 6"])

    def test_empty_program(self):
        result = compile_source("   // nothing here\n")
        self.assertTrue(result["success"])
        self.assertEqual(result["output"], [])

    def test_deep_nesting_does_not_crash(self):
        result = compile_source("int a = " + "(" * 3000 + "1" + ")" * 3000 + ";")
        self.assertFalse(result["success"])
        self.assertIn("nested too deeply", result["errors"][0]["message"])


class TestSamples(unittest.TestCase):
    EXPECTED_OUTPUT = {
        "01_simple_if.txt": ["The number is positive: 15", "Done"],
        "02_if_else.txt": ["27 is odd"],
        "03_else_if_ladder.txt": ["Temperature: 31", "It is warm"],
        "04_nested_if_else.txt": ["2024 is a leap year"],
        "05_logical_operators.txt": ["Allowed to drive", "No parking pass", "Adult with a car or a license",
                                     "canDrive = 1"],
        "06_float_comparison.txt": ["BMI: 22.36734694", "Normal weight", "BMI + 2 = 24.36734694"],
        "07_constant_folding.txt": ["b = 44", "c = 20 and d = 14"],
        "08_grade_calculator.txt": ["Average marks: 83.66666667", "Grade: B",
                                    "Good, but not above 80 in every subject"],
        "09_largest_of_three.txt": ["Largest number is 87"],
        "10_dangling_else_and_scopes.txt": ["x is positive, y is not", "inner value: 99", "outer value: 10"],
        "11_type_conversion.txt": ["price = 7.0", "rounded = 8", "7 / 2 = 3", "7.0 / 2 = 3.5"],
        "12_positive_negative_zero.txt": ["-42 is negative"],
        "13_triangle_type.txt": ["Isosceles triangle"],
        "14_electricity_bill.txt": ["Units used: 260", "10% surcharge added", "Total bill: 704.0"],
        "15_point_quadrant.txt": ["Quadrant II"],
        "16_simple_calculator.txt": ["18.0 / 4 = 4.5"],
        "17_divisibility_check.txt": ["FizzBuzz: 45 is divisible by 3 and 5"],
        "18_discount_calculator.txt": ["Purchase amount: 1500.0", "Discount: 300.0", "Amount to pay: 1200.0"],
        "19_time_of_day.txt": ["Good evening"],
        "20_income_tax.txt": ["Income: 750000", "Senior citizen rebate applied", "Tax payable: 52500.0"],
        "21_access_control.txt": ["Full access"],
        "22_safe_division.txt": ["Skipped: d is 0, so n / d was never computed",
                                 "n / d = 10 which is greater than 2"],
    }

    def test_every_valid_sample_has_an_expected_output(self):
        valid = {f for f in os.listdir(SAMPLES_DIR) if f.endswith(".txt")}
        self.assertEqual(valid, set(self.EXPECTED_OUTPUT))
    EXPECTED_FAILURE = {
        "01_lexical_error.txt": ("Lexer", "invalid character"),
        "02_missing_semicolon.txt": ("Parser", "expected ';'"),
        "03_unmatched_brace.txt": ("Parser", "unmatched '{'"),
        "04_undeclared_variable.txt": ("Semantic", "undeclared variable"),
        "05_redeclaration.txt": ("Semantic", "redeclaration"),
        "06_type_error.txt": ("Semantic", "requires int operands"),
        "07_else_without_if.txt": ("Parser", "'else' without"),
        "08_division_by_zero.txt": ("Execution", "division by zero"),
        "09_unterminated_string.txt": ("Lexer", "unterminated string"),
    }

    def read(self, *parts):
        with open(os.path.join(SAMPLES_DIR, *parts), encoding="utf-8") as handle:
            return handle.read()

    def test_there_are_enough_samples(self):
        valid = [f for f in os.listdir(SAMPLES_DIR) if f.endswith(".txt")]
        errors = [f for f in os.listdir(os.path.join(SAMPLES_DIR, "errors")) if f.endswith(".txt")]
        self.assertGreaterEqual(len(valid), 8)
        self.assertGreaterEqual(len(errors), 5)

    def test_valid_samples(self):
        for filename, expected in self.EXPECTED_OUTPUT.items():
            with self.subTest(sample=filename):
                result = compile_source(self.read(filename))
                self.assertTrue(result["success"], result["errors"])
                self.assertEqual(result["output"], expected)

    def test_error_samples(self):
        for filename, (phase, text) in self.EXPECTED_FAILURE.items():
            with self.subTest(sample=filename):
                result = compile_source(self.read("errors", filename))
                self.assertEqual(result["failed_phase"], phase)
                self.assertIn(text, result["errors"][0]["message"])
                self.assertIsNotNone(result["errors"][0]["line"])


class TestWebApp(unittest.TestCase):
    def setUp(self):
        from app import app
        app.testing = True
        self.client = app.test_client()

    def test_index_page(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Mini Compiler", response.data)
        self.assertIn(b'data-tab="tokens"', response.data)
        self.assertNotIn(b'data-tab="tac"', response.data)  # the page only has Output + Tokens

    def test_samples_endpoint(self):
        data = self.client.get("/api/samples").get_json()
        self.assertEqual([g["name"] for g in data["groups"]], ["Valid Programs", "Error Programs"])
        self.assertGreaterEqual(len(data["groups"][0]["samples"]), 8)

    def test_compile_endpoint(self):
        data = self.client.post("/api/compile", json={"code": "int a = 2; print(a * 21);"}).get_json()
        self.assertTrue(data["success"])
        self.assertEqual(data["output"], ["42"])

    def test_bad_request_is_clean_json(self):
        response = self.client.post("/api/compile", data="not json", content_type="text/plain")
        self.assertEqual(response.status_code, 400)
        self.assertFalse(response.get_json()["success"])

    def test_unknown_route_is_clean_json(self):
        response = self.client.get("/api/nope")
        self.assertEqual(response.status_code, 404)
        self.assertNotIn(b"Traceback", response.data)


if __name__ == "__main__":
    unittest.main()
