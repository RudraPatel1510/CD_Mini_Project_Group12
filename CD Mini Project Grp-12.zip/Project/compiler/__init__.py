"""Mini Compiler for If-Else statements: lexer, parser, semantic analyzer,
intermediate code generator, optimizer and executor."""

from .pipeline import PHASES, compile_source

__all__ = ["compile_source", "PHASES"]
