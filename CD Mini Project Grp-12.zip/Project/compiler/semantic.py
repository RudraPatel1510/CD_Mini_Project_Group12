"""
Phase 3: Semantic Analyzer

Walks the AST with a scoped symbol table (a new scope for every block) and
checks the meaning of the program:
  - variables must be declared before use
  - a name cannot be declared twice in the same scope
  - types: int -> float widening is fine; float -> int gives a warning;
    '%' needs int operands
It also annotates every expression node with its type (node.dtype).
"""

from .ast_nodes import Literal
from .errors import CompilerError, CompilerWarning

PHASE = "Semantic"

ARITHMETIC_OPS = {"+", "-", "*", "/", "%"}


class Symbol:
    """One entry in the symbol table."""

    def __init__(self, name, var_type, scope, depth, line, column):
        self.name = name
        self.var_type = var_type
        self.scope = scope
        self.depth = depth
        self.line = line
        self.column = column
        self.initialized = False
        self.used = 0
        self.warned_uninitialized = False

    def to_dict(self):
        return {
            "name": self.name,
            "type": self.var_type,
            "scope": self.scope,
            "depth": self.depth,
            "line": self.line,
            "initialized": self.initialized,
            "used": self.used,
        }


class SemanticAnalyzer:
    """Checks declarations, scopes and types; collects errors and warnings."""

    def __init__(self):
        self.scopes = []   # stack of (scope_name, {name: Symbol})
        self.symbols = []  # every symbol ever declared, in order
        self.errors = []
        self.warnings = []
        self.block_count = 0

    # ----- reporting ---------------------------------------------------------

    def error(self, message, node):
        self.errors.append(CompilerError(PHASE, message, node.line, node.column))

    def warn(self, message, node):
        self.warnings.append(CompilerWarning(PHASE, message, node.line, node.column))

    # ----- scopes ------------------------------------------------------------

    def enter_scope(self, name):
        self.scopes.append((name, {}))

    def exit_scope(self):
        _, table = self.scopes.pop()
        for symbol in table.values():
            if symbol.used == 0:
                self.warnings.append(CompilerWarning(
                    PHASE, f"variable '{symbol.name}' is declared but never used", symbol.line, symbol.column))

    def declare(self, node):
        scope_name, table = self.scopes[-1]
        if node.name in table:
            first = table[node.name]
            self.error(f"redeclaration of '{node.name}' in the same scope (first declared at line {first.line})",
                       node)
            return None
        symbol = Symbol(node.name, node.var_type, scope_name, len(self.scopes) - 1, node.line, node.column)
        table[node.name] = symbol
        self.symbols.append(symbol)
        return symbol

    def lookup(self, name):
        """Search from the innermost scope outwards."""
        for _, table in reversed(self.scopes):
            if name in table:
                return table[name]
        return None

    # ----- entry point -------------------------------------------------------

    def analyze(self, program):
        """Analyze the program. Returns (symbols, errors, warnings)."""
        self.enter_scope("global")
        for statement in program.statements:
            self.visit(statement)
        self.exit_scope()
        return self.symbols, self.errors, self.warnings

    def visit(self, node):
        method = getattr(self, "visit_" + type(node).__name__)
        return method(node)

    # ----- statements --------------------------------------------------------

    def visit_Block(self, node):
        self.block_count += 1
        self.enter_scope(f"block {self.block_count}")
        for statement in node.statements:
            self.visit(statement)
        self.exit_scope()

    def visit_VarDecl(self, node):
        # The initializer is checked first, so "int x = x;" refers to an outer x.
        value_type = self.visit(node.initializer) if node.initializer else None
        symbol = self.declare(node)
        if symbol and node.initializer:
            symbol.initialized = True
            self.check_assignment(node.var_type, value_type, node.name, node)

    def visit_Assign(self, node):
        value_type = self.visit(node.value)
        symbol = self.lookup(node.name)
        if symbol is None:
            self.error(f"undeclared variable '{node.name}'", node)
            return
        symbol.initialized = True
        self.check_assignment(symbol.var_type, value_type, node.name, node)

    def visit_If(self, node):
        self.visit(node.condition)
        self.visit(node.then_branch)
        if node.else_branch is not None:
            self.visit(node.else_branch)

    def visit_Print(self, node):
        for argument in node.arguments:
            self.visit(argument)

    def visit_StringLiteral(self, node):
        return node.dtype

    def check_assignment(self, target_type, value_type, name, node):
        if target_type == "int" and value_type == "float":
            self.warn(f"implicit conversion from 'float' to 'int' when assigning to '{name}' "
                      f"(the value will be truncated)", node)

    # ----- expressions (each returns its type, or None after an error) -------

    def visit_Literal(self, node):
        return node.dtype

    def visit_Identifier(self, node):
        symbol = self.lookup(node.name)
        if symbol is None:
            self.error(f"undeclared variable '{node.name}'", node)
            return None
        symbol.used += 1
        if not symbol.initialized and not symbol.warned_uninitialized:
            symbol.warned_uninitialized = True
            self.warn(f"variable '{node.name}' is used before it is assigned a value (it defaults to 0)", node)
        node.dtype = symbol.var_type
        return node.dtype

    def visit_UnaryOp(self, node):
        operand_type = self.visit(node.operand)
        if operand_type is None:
            return None
        node.dtype = "int" if node.op == "!" else operand_type
        return node.dtype

    def visit_BinaryOp(self, node):
        left_type = self.visit(node.left)
        right_type = self.visit(node.right)
        if left_type is None or right_type is None:
            return None

        if node.op in ARITHMETIC_OPS:
            if node.op == "%" and "float" in (left_type, right_type):
                self.error("operator '%' requires int operands, but got 'float'", node)
                return None
            if node.op in ("/", "%") and isinstance(node.right, Literal) and node.right.value == 0:
                self.warn("division by zero", node)
            node.dtype = "float" if "float" in (left_type, right_type) else "int"
        else:
            # Relational and logical operators produce 1 (true) or 0 (false).
            if node.op in ("==", "!=") and "float" in (left_type, right_type):
                self.warn(f"comparing floating-point values with '{node.op}' can be unreliable", node)
            node.dtype = "int"
        return node.dtype


def analyze(program):
    """Run semantic analysis. Returns (symbols, errors, warnings)."""
    return SemanticAnalyzer().analyze(program)
