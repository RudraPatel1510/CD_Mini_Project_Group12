"""
Runs every compiler phase in order and packs the results into one
JSON-friendly dict. If a phase fails, the later phases are skipped but the
results of the earlier phases are still returned.
"""

import time

from .errors import CompilerError, CompilerWarning
from .executor import run_tac
from .icg import generate
from .lexer import tokenize
from .optimizer import optimize
from .parser import parse
from .semantic import analyze

PHASES = ["Lexer", "Parser", "Semantic", "ICG", "Optimizer", "Execution"]


def compile_source(source):
    """Compile and run `source`. Always returns a dict; never raises."""
    result = {
        "success": False,
        "failed_phase": None,
        "phases": [],
        "tokens": [],
        "ast": None,
        "symbol_table": [],
        "tac": [],
        "optimized_tac": [],
        "output": [],
        "errors": [],
        "warnings": [],
        "time_ms": 0,
    }
    status = {phase: "skipped" for phase in PHASES}
    started = time.perf_counter()

    try:
        _run_phases(source, result, status)
    except Exception as exc:  # a bug in the compiler itself; never show a traceback
        current = next(phase for phase in PHASES if status[phase] == "skipped")
        message = ("program is nested too deeply to compile" if isinstance(exc, RecursionError)
                   else f"internal compiler error: {exc}")
        _fail(result, status, current, [CompilerError(current, message)])

    result["success"] = result["failed_phase"] is None
    result["phases"] = [{"name": phase, "status": status[phase]} for phase in PHASES]
    result["time_ms"] = round((time.perf_counter() - started) * 1000, 2)
    return result


def _fail(result, status, phase, errors):
    status[phase] = "failed"
    result["failed_phase"] = phase
    result["errors"].extend(error.to_dict() for error in errors)


def _run_phases(source, result, status):
    # 1. Lexical analysis
    tokens, lex_errors = tokenize(source)
    result["tokens"] = [token.to_dict() for token in tokens]
    if lex_errors:
        return _fail(result, status, "Lexer", lex_errors)
    status["Lexer"] = "passed"

    # 2. Syntax analysis
    try:
        program = parse(tokens)
    except CompilerError as error:
        return _fail(result, status, "Parser", [error])
    status["Parser"] = "passed"
    if not program.statements:
        result["warnings"].append(CompilerWarning("Parser", "the program is empty").to_dict())

    # 3. Semantic analysis (also fills in the type of every expression)
    symbols, sem_errors, sem_warnings = analyze(program)
    result["ast"] = program.to_dict()
    result["symbol_table"] = [symbol.to_dict() for symbol in symbols]
    result["warnings"].extend(warning.to_dict() for warning in sem_warnings)
    if sem_errors:
        return _fail(result, status, "Semantic", sem_errors)
    status["Semantic"] = "passed"

    # 4. Intermediate code generation
    tac, temps = generate(program)
    result["tac"] = [str(instr) for instr in tac]
    status["ICG"] = "passed"

    # 5. Optimization
    optimized = optimize(tac, temps)
    result["optimized_tac"] = [str(instr) for instr in optimized]
    status["Optimizer"] = "passed"

    # 6. Execution
    output, runtime_error = run_tac(optimized)
    result["output"] = output
    if runtime_error:
        return _fail(result, status, "Execution", [runtime_error])
    status["Execution"] = "passed"
