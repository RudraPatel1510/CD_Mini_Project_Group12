"""
Abstract Syntax Tree (AST) node classes.

The parser builds these nodes; later phases walk them. Every node can turn
itself into a nested dict with to_dict() so the web UI can draw the tree.
Expression nodes get a `dtype` ("int" / "float") filled in by the semantic
analyzer.
"""


class Node:
    """Base class for all AST nodes."""

    def __init__(self, line=0, column=0):
        self.line = line
        self.column = column

    def to_dict(self):
        raise NotImplementedError

    def _dict(self, label, detail="", children=()):
        return {
            "type": type(self).__name__,
            "label": label,
            "detail": detail,
            "line": self.line,
            "dtype": getattr(self, "dtype", None),
            "children": list(children),
        }


def _child(role, node):
    """Convert a child node and tag it with its role (e.g. 'condition')."""
    data = node.to_dict()
    data["role"] = role
    return data


# ----- statements -------------------------------------------------------------

class Program(Node):
    def __init__(self, statements, line=1, column=1):
        super().__init__(line, column)
        self.statements = statements

    def to_dict(self):
        return self._dict("Program", f"{len(self.statements)} statement(s)",
                          [s.to_dict() for s in self.statements])


class Block(Node):
    def __init__(self, statements, line, column):
        super().__init__(line, column)
        self.statements = statements

    def to_dict(self):
        return self._dict("Block", "{ ... }", [s.to_dict() for s in self.statements])


class VarDecl(Node):
    def __init__(self, var_type, name, initializer, line, column):
        super().__init__(line, column)
        self.var_type = var_type
        self.name = name
        self.initializer = initializer

    def to_dict(self):
        children = [_child("value", self.initializer)] if self.initializer else []
        return self._dict("Declaration", f"{self.var_type} {self.name}", children)


class Assign(Node):
    def __init__(self, name, value, line, column):
        super().__init__(line, column)
        self.name = name
        self.value = value

    def to_dict(self):
        return self._dict("Assignment", f"{self.name} =", [_child("value", self.value)])


class If(Node):
    def __init__(self, condition, then_branch, else_branch, line, column):
        super().__init__(line, column)
        self.condition = condition
        self.then_branch = then_branch
        self.else_branch = else_branch

    def to_dict(self):
        children = [_child("condition", self.condition), _child("then", self.then_branch)]
        if self.else_branch is not None:
            children.append(_child("else", self.else_branch))
        return self._dict("If", "if-else" if self.else_branch else "if", children)


class Print(Node):
    """print(a, b, ...): each argument is an expression or a StringLiteral."""

    def __init__(self, arguments, line, column):
        super().__init__(line, column)
        self.arguments = arguments

    def to_dict(self):
        return self._dict("Print", "print(...)", [_child("arg", a) for a in self.arguments])


class StringLiteral(Node):
    """Text in quotes. Only allowed as a print argument."""

    def __init__(self, value, line, column):
        super().__init__(line, column)
        self.value = value
        self.dtype = "string"

    def to_dict(self):
        return self._dict("StringLiteral", repr(self.value))


# ----- expressions ------------------------------------------------------------

class Expression(Node):
    def __init__(self, line, column):
        super().__init__(line, column)
        self.dtype = None


class BinaryOp(Expression):
    def __init__(self, op, left, right, line, column):
        super().__init__(line, column)
        self.op = op
        self.left = left
        self.right = right

    def to_dict(self):
        return self._dict("BinaryOp", self.op, [_child("left", self.left), _child("right", self.right)])


class UnaryOp(Expression):
    def __init__(self, op, operand, line, column):
        super().__init__(line, column)
        self.op = op
        self.operand = operand

    def to_dict(self):
        return self._dict("UnaryOp", self.op, [_child("operand", self.operand)])


class Literal(Expression):
    def __init__(self, value, lit_type, line, column):
        super().__init__(line, column)
        self.value = value
        self.dtype = lit_type

    def to_dict(self):
        return self._dict("Literal", str(self.value))


class Identifier(Expression):
    def __init__(self, name, line, column):
        super().__init__(line, column)
        self.name = name

    def to_dict(self):
        return self._dict("Identifier", self.name)
