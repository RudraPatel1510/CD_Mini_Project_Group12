"""
Phase 5: Code Optimizer

Improves the TAC with these passes, repeated until nothing changes:

  1. Constant propagation    - inside a basic block, replace a variable whose
                               value is a known constant with that constant.
  2. Constant folding        - compute operations whose operands are all
                               constants at compile time (2 + 3 -> 5).
  3. Dead-branch elimination - "if 1 goto L" becomes "goto L";
                               "if 0 goto L" is deleted.
  4. Clean-up                - remove unreachable code after a goto, jumps to
                               the very next line, labels nobody jumps to, and
                               temporaries that are never read.

Propagation only trusts what it has seen since the last label, because
control can arrive at a label from more than one place.

Each pass takes the code and returns (new_code, changed).
"""

from .tac import apply_binary, apply_unary, is_const, is_true

MAX_PASSES = 50


def fold_and_propagate(code):
    """Constant propagation + constant folding over each basic block."""
    changed = False
    known = {}  # name -> constant value, valid until the next label
    for instr in code:
        if instr.kind == "label":
            known.clear()
            continue

        for field in ("arg1", "arg2"):
            operand = getattr(instr, field)
            if isinstance(operand, str) and operand in known:
                setattr(instr, field, known[operand])
                changed = True

        try:
            if instr.kind == "binop" and is_const(instr.arg1) and is_const(instr.arg2):
                value = apply_binary(instr.op, instr.arg1, instr.arg2)
                instr.kind, instr.arg1, instr.op, instr.arg2 = "copy", value, None, None
                changed = True
            elif instr.kind == "unop" and is_const(instr.arg1):
                value = apply_unary(instr.op, instr.arg1)
                instr.kind, instr.arg1, instr.op = "copy", value, None
                changed = True
            elif instr.kind == "if" and instr.op and is_const(instr.arg1) and is_const(instr.arg2):
                instr.arg1 = apply_binary(instr.op, instr.arg1, instr.arg2)
                instr.op, instr.arg2 = None, None
                changed = True
        except ZeroDivisionError:
            pass  # leave it for the executor to report at run time

        if instr.result is not None:
            if instr.kind == "copy" and is_const(instr.arg1):
                known[instr.result] = instr.arg1
            else:
                known.pop(instr.result, None)
    return code, changed


def eliminate_dead_branches(code):
    """Resolve conditional jumps whose condition is now a constant."""
    result, changed = [], False
    for instr in code:
        if instr.kind == "if" and instr.op is None and is_const(instr.arg1):
            changed = True
            if is_true(instr.arg1):          # always true: jump unconditionally
                instr.kind, instr.arg1 = "goto", None
                result.append(instr)
            continue                         # always false: drop the jump
        result.append(instr)
    return result, changed


def remove_unreachable(code):
    """Code after an unconditional goto can only be reached through a label."""
    result, changed, reachable = [], False, True
    for instr in code:
        if instr.kind == "label":
            reachable = True
        if reachable:
            result.append(instr)
        else:
            changed = True
        if instr.kind == "goto":
            reachable = False
    return result, changed


def remove_redundant_jumps(code):
    """A jump to a label that immediately follows it does nothing."""
    result, changed = [], False
    for index, instr in enumerate(code):
        if instr.kind in ("goto", "if"):
            following_labels = set()
            for later in code[index + 1:]:
                if later.kind != "label":
                    break
                following_labels.add(later.label)
            if instr.label in following_labels:
                changed = True
                continue
        result.append(instr)
    return result, changed


def remove_unused_labels(code):
    targets = {instr.label for instr in code if instr.kind in ("goto", "if")}
    result = [instr for instr in code if instr.kind != "label" or instr.label in targets]
    return result, len(result) != len(code)


def remove_dead_temporaries(code, temps):
    """Delete assignments to temporaries that no instruction ever reads."""
    read = {name for instr in code for name in instr.reads()}
    result = []
    for instr in code:
        unused_temp = instr.result in temps and instr.result not in read
        may_fail = instr.op in ("/", "%") and not (is_const(instr.arg2) and instr.arg2 != 0)
        if not (unused_temp and not may_fail):
            result.append(instr)
    return result, len(result) != len(code)


def optimize(code, temps=frozenset()):
    """Optimize a list of TAC instructions. The input list is not modified."""
    code = [instr.copy() for instr in code]
    for _ in range(MAX_PASSES):
        any_change = False
        for apply_pass in (fold_and_propagate, eliminate_dead_branches, remove_unreachable,
                           remove_redundant_jumps, remove_unused_labels):
            code, changed = apply_pass(code)
            any_change = any_change or changed
        code, changed = remove_dead_temporaries(code, temps)
        if not (any_change or changed):
            break
    return code
