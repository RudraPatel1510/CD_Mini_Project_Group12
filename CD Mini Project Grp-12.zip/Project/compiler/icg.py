"""
Phase 4: Intermediate Code Generator

Translates the (type-annotated) AST into Three-Address Code using temporaries
t1, t2, ... and labels L1, L2, ...

Conditions use textbook "jumping code":
    if a < b goto L1
    goto L2
&& and || are short-circuited: the right operand is only evaluated when the
left one does not already decide the result.

If-else layout:
        <condition jumps to Ltrue / Lfalse>
    Ltrue:
        <then-branch>
        goto Lend
    Lfalse:
        <else-branch>
    Lend:
"""

from .ast_nodes import BinaryOp, Block, Identifier, If, Literal, StringLiteral, UnaryOp, VarDecl
from .tac import RELATIONAL_OPS, Instr, Text


def collect_declared_names(statements, names):
    """Gather every variable name declared anywhere in the program."""
    for statement in statements:
        if isinstance(statement, VarDecl):
            names.add(statement.name)
        elif isinstance(statement, Block):
            collect_declared_names(statement.statements, names)
        elif isinstance(statement, If):
            branches = [statement.then_branch]
            if statement.else_branch is not None:
                branches.append(statement.else_branch)
            collect_declared_names(branches, names)


class ICGenerator:
    """Walks the AST and emits a flat list of TAC instructions."""

    def __init__(self):
        self.code = []
        self.temps = set()
        self.temp_count = 0
        self.label_count = 0
        self.scopes = []               # stack of {source name: (tac name, type)}
        self.taken_names = set()       # names that temporaries/renames must avoid
        self.declared_tac_names = set()
        self.current_line = None

    # ----- helpers -----------------------------------------------------------

    def emit(self, kind, **fields):
        self.code.append(Instr(kind, line=self.current_line, **fields))

    def new_temp(self):
        while True:  # skip t<n> names the user already took for variables
            self.temp_count += 1
            name = f"t{self.temp_count}"
            if name not in self.taken_names:
                break
        self.temps.add(name)
        return name

    def new_label(self):
        self.label_count += 1
        return f"L{self.label_count}"

    def declare(self, name, var_type):
        """Give each declaration a unique TAC name (shadowed variables get x_1, x_2...)."""
        tac_name = name
        suffix = 0
        # A renamed variable must not clash with any user name or earlier TAC name.
        while tac_name in self.declared_tac_names or (suffix and tac_name in self.taken_names):
            suffix += 1
            tac_name = f"{name}_{suffix}"
        self.declared_tac_names.add(tac_name)
        self.taken_names.add(tac_name)
        self.scopes[-1][name] = (tac_name, var_type)
        return tac_name

    def lookup(self, name):
        for scope in reversed(self.scopes):
            if name in scope:
                return scope[name]
        raise KeyError(name)  # cannot happen after semantic analysis

    # ----- entry point -------------------------------------------------------

    def generate(self, program):
        """Return the list of TAC instructions for the program."""
        collect_declared_names(program.statements, self.taken_names)
        self.scopes.append({})
        for statement in program.statements:
            self.gen_statement(statement)
        self.scopes.pop()
        return self.code

    # ----- statements --------------------------------------------------------

    def gen_statement(self, node):
        self.current_line = node.line
        method = getattr(self, "gen_" + type(node).__name__)
        method(node)

    def gen_Block(self, node):
        self.scopes.append({})
        for statement in node.statements:
            self.gen_statement(statement)
        self.scopes.pop()

    def gen_VarDecl(self, node):
        tac_name = self.declare(node.name, node.var_type)
        if node.initializer is None:
            default = 0.0 if node.var_type == "float" else 0
            self.emit("copy", result=tac_name, arg1=default)
        else:
            self.gen_assignment(tac_name, node.var_type, node.initializer)

    def gen_Assign(self, node):
        tac_name, var_type = self.lookup(node.name)
        self.gen_assignment(tac_name, var_type, node.value)

    def gen_assignment(self, target, target_type, expression):
        """Store an expression into a variable, adding a cast if the types differ."""
        if expression.dtype == target_type:
            self.gen_expr(expression, target)
        else:
            value = self.gen_expr(expression)
            self.emit("unop", result=target, op=target_type, arg1=value)

    def gen_Print(self, node):
        """print(a, b, c) -> write a / write b / print c  (print ends the line)."""
        values = [Text(arg.value) if isinstance(arg, StringLiteral) else self.gen_expr(arg)
                  for arg in node.arguments] or [Text("")]
        self.current_line = node.line
        for value in values[:-1]:
            self.emit("write", arg1=value)
        self.emit("print", arg1=values[-1])

    def gen_If(self, node):
        true_label = self.new_label()
        false_label = self.new_label()
        self.gen_condition(node.condition, true_label, false_label)
        self.emit("label", label=true_label)
        self.gen_statement(node.then_branch)
        if node.else_branch is None:
            self.emit("label", label=false_label)
        else:
            end_label = self.new_label()
            self.current_line = node.line
            self.emit("goto", label=end_label)
            self.emit("label", label=false_label)
            self.gen_statement(node.else_branch)
            self.emit("label", label=end_label)

    # ----- conditions (jumping code) -----------------------------------------

    def gen_condition(self, node, true_label, false_label):
        """Emit code that jumps to true_label if node is true, else false_label."""
        if isinstance(node, BinaryOp) and node.op == "&&":
            middle = self.new_label()
            self.gen_condition(node.left, middle, false_label)   # left false -> skip right
            self.emit("label", label=middle)
            self.gen_condition(node.right, true_label, false_label)
        elif isinstance(node, BinaryOp) and node.op == "||":
            middle = self.new_label()
            self.gen_condition(node.left, true_label, middle)    # left true -> skip right
            self.emit("label", label=middle)
            self.gen_condition(node.right, true_label, false_label)
        elif isinstance(node, UnaryOp) and node.op == "!":
            self.gen_condition(node.operand, false_label, true_label)
        elif isinstance(node, BinaryOp) and node.op in RELATIONAL_OPS:
            left = self.gen_expr(node.left)
            right = self.gen_expr(node.right)
            self.emit("if", arg1=left, op=node.op, arg2=right, label=true_label)
            self.emit("goto", label=false_label)
        else:
            value = self.gen_expr(node)
            self.emit("if", arg1=value, label=true_label)
            self.emit("goto", label=false_label)

    # ----- expressions -------------------------------------------------------

    def gen_expr(self, node, target=None):
        """
        Emit code for an expression and return the operand holding its value.
        If `target` is given, the result is stored directly into that name.
        """
        if isinstance(node, Literal):
            if target:
                self.emit("copy", result=target, arg1=node.value)
                return target
            return node.value

        if isinstance(node, Identifier):
            name, _ = self.lookup(node.name)
            if target:
                self.emit("copy", result=target, arg1=name)
                return target
            return name

        if isinstance(node, BinaryOp) and node.op in ("&&", "||"):
            return self.gen_logical_value(node, target)

        if isinstance(node, BinaryOp):
            left = self.gen_expr(node.left)
            right = self.gen_expr(node.right)
            dest = target or self.new_temp()
            self.emit("binop", result=dest, arg1=left, op=node.op, arg2=right)
            return dest

        if isinstance(node, UnaryOp):
            operand = self.gen_expr(node.operand)
            dest = target or self.new_temp()
            self.emit("unop", result=dest, op=node.op, arg1=operand)
            return dest

        raise TypeError(f"unknown expression node {type(node).__name__}")

    def gen_logical_value(self, node, target):
        """&& / || used as a value: evaluate with jumps, then store 1 or 0."""
        dest = target or self.new_temp()
        true_label, false_label, end_label = self.new_label(), self.new_label(), self.new_label()
        self.gen_condition(node, true_label, false_label)
        self.emit("label", label=true_label)
        self.emit("copy", result=dest, arg1=1)
        self.emit("goto", label=end_label)
        self.emit("label", label=false_label)
        self.emit("copy", result=dest, arg1=0)
        self.emit("label", label=end_label)
        return dest


def generate(program):
    """Generate TAC. Returns (instructions, set_of_temporary_names)."""
    generator = ICGenerator()
    code = generator.generate(program)
    return code, generator.temps
