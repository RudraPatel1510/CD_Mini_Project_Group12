"""
Phase 2: Syntax Analyzer (hand-written recursive descent parser)

Grammar in BNF. { x } means "zero or more x", [ x ] means "optional x".
Each non-terminal below has a matching parse_<name> method.

    <program>        ::= { <statement> } EOF

    <statement>      ::= <declaration>
                       | <assignment>
                       | <if_stmt>
                       | <print_stmt>
                       | <block>

    <declaration>    ::= <type> IDENTIFIER [ "=" <expression> ] ";"
    <type>           ::= "int" | "float"
    <assignment>     ::= IDENTIFIER "=" <expression> ";"
    <if_stmt>        ::= "if" "(" <expression> ")" <statement> [ "else" <statement> ]
    <print_stmt>     ::= "print" "(" [ <print_arg> { "," <print_arg> } ] ")" ";"
    <print_arg>      ::= STRING_LITERAL | <expression>
    <block>          ::= "{" { <statement> } "}"

    <expression>     ::= <logic_or>
    <logic_or>       ::= <logic_and> { "||" <logic_and> }
    <logic_and>      ::= <equality> { "&&" <equality> }
    <equality>       ::= <relational> { ( "==" | "!=" ) <relational> }
    <relational>     ::= <additive> { ( "<" | ">" | "<=" | ">=" ) <additive> }
    <additive>       ::= <term> { ( "+" | "-" ) <term> }
    <term>           ::= <unary> { ( "*" | "/" | "%" ) <unary> }
    <unary>          ::= ( "!" | "-" | "+" ) <unary> | <primary>
    <primary>        ::= INT_LITERAL | FLOAT_LITERAL | IDENTIFIER | "(" <expression> ")"

Precedence (lowest to highest): ||, &&, == !=, < > <= >=, + -, * / %, unary.
All binary operators are left-associative.

Dangling else: parse_if() takes an "else" immediately after the then-branch,
so an else always binds to the nearest unmatched if.
"""

from .ast_nodes import (Assign, BinaryOp, Block, Identifier, If, Literal, Print, Program, StringLiteral,
                        UnaryOp, VarDecl)
from .errors import CompilerError
from .lexer import string_value

PHASE = "Parser"

OPERATOR_TYPES = ("ARITH_OP", "REL_OP", "LOGICAL_OP")


def describe(token):
    """Human-friendly description of a token for error messages."""
    if token.type == "EOF":
        return "end of input"
    if token.type == "KEYWORD":
        return f"keyword '{token.value}'"
    return f"'{token.value}'"


class Parser:
    """Builds an AST from the token list produced by the lexer."""

    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    # ----- token helpers -----------------------------------------------------

    def current(self):
        return self.tokens[self.pos]

    def previous(self):
        return self.tokens[self.pos - 1] if self.pos > 0 else self.tokens[0]

    def check(self, type_, value=None):
        token = self.current()
        return token.type == type_ and (value is None or token.value == value)

    def advance(self):
        token = self.current()
        if token.type != "EOF":
            self.pos += 1
        return token

    def error(self, message, token=None):
        token = token or self.current()
        return CompilerError(PHASE, message, token.line, token.column)

    def expect(self, type_, value, message):
        """Consume the expected token or raise an error that names what was found."""
        if self.check(type_, value):
            return self.advance()
        raise self.error(f"{message}, found {describe(self.current())}")

    def expect_semicolon(self, message):
        """Missing ';' is reported on the line of the statement, not the next line."""
        if self.check("SEMICOLON"):
            return self.advance()
        last = self.previous()
        raise CompilerError(PHASE, message, last.line, last.column + len(last.value))

    # ----- statements --------------------------------------------------------

    def parse_program(self):
        statements = []
        while not self.check("EOF"):
            statements.append(self.parse_statement())
        return Program(statements)

    def parse_statement(self):
        token = self.current()
        if token.type == "KEYWORD":
            if token.value in ("int", "float"):
                return self.parse_declaration()
            if token.value == "if":
                return self.parse_if()
            if token.value == "print":
                return self.parse_print()
            if token.value == "else":
                raise self.error("'else' without a matching 'if'")
        if token.type == "IDENTIFIER":
            return self.parse_assignment()
        if token.type == "LBRACE":
            return self.parse_block()
        if token.type == "RBRACE":
            raise self.error("unexpected '}' with no matching '{'")
        if token.type == "EOF":
            raise self.error("unexpected end of input, expected a statement")
        raise self.error(f"unexpected {describe(token)} at the start of a statement")

    def parse_declaration(self):
        type_token = self.advance()
        name_token = self.expect("IDENTIFIER", None, f"expected variable name after '{type_token.value}'")
        initializer = None
        if self.check("ASSIGN"):
            self.advance()
            initializer = self.parse_expression()
        self.expect_semicolon(f"expected ';' after declaration of '{name_token.value}'")
        return VarDecl(type_token.value, name_token.value, initializer, type_token.line, type_token.column)

    def parse_assignment(self):
        name_token = self.advance()
        if not self.check("ASSIGN"):
            raise self.error(f"expected '=' after '{name_token.value}' "
                             f"(an expression on its own is not a statement), found {describe(self.current())}")
        self.advance()
        value = self.parse_expression()
        self.expect_semicolon("expected ';' after expression")
        return Assign(name_token.value, value, name_token.line, name_token.column)

    def parse_if(self):
        if_token = self.advance()
        self.expect("LPAREN", None, "expected '(' after 'if'")
        condition = self.parse_expression()
        if not self.check("RPAREN"):
            hint = " (did you mean '=='?)" if self.check("ASSIGN") else ""
            raise self.error(f"expected ')' after if condition, found {describe(self.current())}{hint}")
        self.advance()

        then_branch = self.parse_branch("if")
        else_branch = None
        if self.check("KEYWORD", "else"):  # binds to this (the nearest) if
            self.advance()
            else_branch = self.parse_branch("else")
        return If(condition, then_branch, else_branch, if_token.line, if_token.column)

    def parse_branch(self, keyword):
        """The body of an if/else: any statement except a bare declaration."""
        if self.check("KEYWORD", "int") or self.check("KEYWORD", "float"):
            raise self.error(f"a declaration cannot be the body of '{keyword}'; wrap it in {{ }}")
        return self.parse_statement()

    def parse_print(self):
        print_token = self.advance()
        self.expect("LPAREN", None, "expected '(' after 'print'")
        arguments = []
        if not self.check("RPAREN"):
            arguments.append(self.parse_print_argument())
            while self.check("COMMA"):
                self.advance()
                arguments.append(self.parse_print_argument())
        if not self.check("RPAREN") and self.current().type in OPERATOR_TYPES \
                and isinstance(arguments[-1], StringLiteral):
            raise self.error(f"text cannot be combined with '{self.current().value}'; "
                             "separate the values with commas, e.g. print(\"Total:\", x)")
        self.expect("RPAREN", None, "expected ')' after print arguments")
        self.expect_semicolon("expected ';' after expression")
        return Print(arguments, print_token.line, print_token.column)

    def parse_print_argument(self):
        if self.check("STRING_LITERAL"):
            token = self.advance()
            return StringLiteral(string_value(token.value), token.line, token.column)
        return self.parse_expression()

    def parse_block(self):
        open_brace = self.advance()
        statements = []
        while not self.check("RBRACE"):
            if self.check("EOF"):
                raise self.error("unmatched '{': this block is never closed (expected '}' before end of input)",
                                 open_brace)
            statements.append(self.parse_statement())
        self.advance()
        return Block(statements, open_brace.line, open_brace.column)

    # ----- expressions (one method per precedence level) ---------------------

    def parse_expression(self):
        return self.parse_logic_or()

    def parse_binary(self, next_level, operators):
        """Parse a left-associative chain: next_level { op next_level }."""
        left = next_level()
        while self.current().type in OPERATOR_TYPES and self.current().value in operators:
            op_token = self.advance()
            right = next_level()
            left = BinaryOp(op_token.value, left, right, op_token.line, op_token.column)
        return left

    def parse_logic_or(self):
        return self.parse_binary(self.parse_logic_and, ("||",))

    def parse_logic_and(self):
        return self.parse_binary(self.parse_equality, ("&&",))

    def parse_equality(self):
        return self.parse_binary(self.parse_relational, ("==", "!="))

    def parse_relational(self):
        return self.parse_binary(self.parse_additive, ("<", ">", "<=", ">="))

    def parse_additive(self):
        return self.parse_binary(self.parse_term, ("+", "-"))

    def parse_term(self):
        return self.parse_binary(self.parse_unary, ("*", "/", "%"))

    def parse_unary(self):
        token = self.current()
        if token.type in OPERATOR_TYPES and token.value in ("!", "-", "+"):
            self.advance()
            operand = self.parse_unary()
            if token.value == "+":
                return operand  # unary plus does nothing
            return UnaryOp(token.value, operand, token.line, token.column)
        return self.parse_primary()

    def parse_primary(self):
        token = self.current()
        if token.type == "INT_LITERAL":
            self.advance()
            return Literal(int(token.value), "int", token.line, token.column)
        if token.type == "FLOAT_LITERAL":
            self.advance()
            return Literal(float(token.value), "float", token.line, token.column)
        if token.type == "IDENTIFIER":
            self.advance()
            return Identifier(token.value, token.line, token.column)
        if token.type == "LPAREN":
            self.advance()
            expression = self.parse_expression()
            self.expect("RPAREN", None, "expected ')' to close '('")
            return expression
        if token.type == "STRING_LITERAL":
            raise self.error("text in quotes can only be used as an argument of print(...)")
        raise self.error(f"expected an expression, found {describe(token)}")


def parse(tokens):
    """Parse a token list into a Program AST (raises CompilerError)."""
    return Parser(tokens).parse_program()
