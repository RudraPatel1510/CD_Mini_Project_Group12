"""
Three-Address Code (TAC): the instruction format shared by the code
generator, the optimizer and the executor, plus the arithmetic rules used by
both constant folding and execution (so the two always agree).

Instruction kinds and how they print:
    copy    x = y
    binop   x = y op z
    unop    x = minus y | x = not y | x = (int) y | x = (float) y
    label   L1:
    goto    goto L1
    if      if y op z goto L1     (or "if y goto L1" for a plain value)
    write   write y               (output y, stay on the same line)
    print   print y               (output y and end the line)

Operands are variable/temporary names (str), numbers (int/float), or
text constants (Text) used by print.
"""

UNARY_NAMES = {"-": "minus", "!": "not", "int": "(int)", "float": "(float)"}
RELATIONAL_OPS = {"<", ">", "<=", ">=", "==", "!="}


class Text:
    """A text constant such as "Grade:" (kept separate from variable names)."""

    def __init__(self, value):
        self.value = value

    def __eq__(self, other):
        return isinstance(other, Text) and other.value == self.value

    def __hash__(self):
        return hash(self.value)

    def __str__(self):
        escaped = (self.value.replace("\\", "\\\\").replace('"', '\\"')
                   .replace("\n", "\\n").replace("\t", "\\t"))
        return f'"{escaped}"'


def is_const(operand):
    """True for numeric constants."""
    return isinstance(operand, (int, float)) and not isinstance(operand, bool)


def format_number(value):
    """Ints print as-is; floats always show a decimal point (5.0, 2.5)."""
    if isinstance(value, int):
        return str(value)
    text = f"{value:.10g}"
    if not any(ch in text for ch in ".eni"):  # e = exponent, n/i = nan/inf
        text += ".0"
    return text


def format_operand(operand):
    return format_number(operand) if is_const(operand) else str(operand)


class Instr:
    """One three-address instruction."""

    def __init__(self, kind, result=None, arg1=None, op=None, arg2=None, label=None, line=None):
        self.kind = kind
        self.result = result
        self.arg1 = arg1
        self.op = op
        self.arg2 = arg2
        self.label = label
        self.line = line  # source line, used in run-time error messages

    def copy(self):
        return Instr(self.kind, self.result, self.arg1, self.op, self.arg2, self.label, self.line)

    def reads(self):
        """Names of variables/temporaries this instruction reads."""
        return [a for a in (self.arg1, self.arg2) if isinstance(a, str)]

    def __str__(self):
        a, b = format_operand(self.arg1), format_operand(self.arg2)
        if self.kind == "copy":
            return f"{self.result} = {a}"
        if self.kind == "binop":
            return f"{self.result} = {a} {self.op} {b}"
        if self.kind == "unop":
            return f"{self.result} = {UNARY_NAMES[self.op]} {a}"
        if self.kind == "label":
            return f"{self.label}:"
        if self.kind == "goto":
            return f"goto {self.label}"
        if self.kind == "if":
            condition = f"{a} {self.op} {b}" if self.op else a
            return f"if {condition} goto {self.label}"
        return f"{self.kind} {a}"  # write / print

    __repr__ = __str__


# ----- arithmetic shared by the optimizer and the executor --------------------

def _c_divide(a, b):
    """Integer division that truncates toward zero, like C."""
    quotient = abs(a) // abs(b)
    return quotient if (a >= 0) == (b >= 0) else -quotient


def apply_binary(op, a, b):
    """Evaluate `a op b`. Raises ZeroDivisionError for / or % by zero."""
    both_int = isinstance(a, int) and isinstance(b, int)
    if op in ("/", "%") and b == 0:
        raise ZeroDivisionError("division by zero")
    if op == "+":
        return a + b
    if op == "-":
        return a - b
    if op == "*":
        return a * b
    if op == "/":
        return _c_divide(a, b) if both_int else a / b
    if op == "%":
        return a - _c_divide(a, b) * b if both_int else a % b
    if op == "<":
        return int(a < b)
    if op == ">":
        return int(a > b)
    if op == "<=":
        return int(a <= b)
    if op == ">=":
        return int(a >= b)
    if op == "==":
        return int(a == b)
    if op == "!=":
        return int(a != b)
    raise ValueError(f"unknown operator {op}")


def apply_unary(op, a):
    if op == "-":
        return -a
    if op == "!":
        return int(a == 0)
    if op == "int":
        return int(a)  # truncates toward zero
    if op == "float":
        return float(a)
    raise ValueError(f"unknown unary operator {op}")


def is_true(value):
    return value != 0
