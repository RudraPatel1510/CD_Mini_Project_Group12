"""
Phase 6: Execution

Interprets the optimized Three-Address Code instruction by instruction,
like a tiny virtual machine, and collects what the program prints.
"""

from .errors import CompilerError
from .tac import Text, apply_binary, apply_unary, format_number, is_const, is_true

PHASE = "Execution"
MAX_STEPS = 100_000


def run_tac(code):
    """
    Execute TAC. Returns (output_lines, error) where error is a CompilerError
    for run-time failures such as division by zero, or None.
    """
    labels = {instr.label: index for index, instr in enumerate(code) if instr.kind == "label"}
    memory = {}       # variable / temporary name -> value
    output = []       # finished output lines
    line_parts = []   # values written so far on the current line

    def value_of(operand, instr):
        if is_const(operand):
            return operand
        if isinstance(operand, Text):
            return operand.value
        if operand not in memory:
            raise CompilerError(PHASE, f"'{operand}' has no value", instr.line)
        return memory[operand]

    pc, steps = 0, 0  # pc = index of the next instruction to run
    try:
        while pc < len(code):
            steps += 1
            if steps > MAX_STEPS:
                raise CompilerError(PHASE, f"execution stopped after {MAX_STEPS} steps")
            instr = code[pc]
            pc += 1
            kind = instr.kind

            if kind == "copy":
                memory[instr.result] = value_of(instr.arg1, instr)
            elif kind == "binop":
                a, b = value_of(instr.arg1, instr), value_of(instr.arg2, instr)
                try:
                    memory[instr.result] = apply_binary(instr.op, a, b)
                except ZeroDivisionError:
                    raise CompilerError(PHASE, "division by zero", instr.line) from None
            elif kind == "unop":
                memory[instr.result] = apply_unary(instr.op, value_of(instr.arg1, instr))
            elif kind == "goto":
                pc = labels[instr.label]
            elif kind == "if":
                a = value_of(instr.arg1, instr)
                condition = apply_binary(instr.op, a, value_of(instr.arg2, instr)) if instr.op else a
                if is_true(condition):
                    pc = labels[instr.label]
            elif kind in ("write", "print"):
                value = value_of(instr.arg1, instr)
                line_parts.append(value if isinstance(value, str) else format_number(value))
                if kind == "print":  # values are separated by spaces; "\n" in text starts a new line
                    output.extend(" ".join(line_parts).split("\n"))
                    line_parts = []
            # labels need no action
    except CompilerError as error:
        return output, error
    except OverflowError:
        return output, CompilerError(PHASE, "numeric overflow", code[pc - 1].line)
    return output, None
