"""
Phase 1: Lexical Analyzer

Turns source text into a list of tokens. Each token records its type, its
lexeme (value), and the line/column where it starts. Invalid characters are
collected as errors so the user sees all of them at once.
"""

from .errors import CompilerError

PHASE = "Lexer"

KEYWORDS = {"int", "float", "if", "else", "print"}

# Checked before single-character operators so "<=" is not read as "<" "=".
TWO_CHAR_OPERATORS = {
    "<=": "REL_OP",
    ">=": "REL_OP",
    "==": "REL_OP",
    "!=": "REL_OP",
    "&&": "LOGICAL_OP",
    "||": "LOGICAL_OP",
}

ONE_CHAR_OPERATORS = {
    "+": "ARITH_OP",
    "-": "ARITH_OP",
    "*": "ARITH_OP",
    "/": "ARITH_OP",
    "%": "ARITH_OP",
    "<": "REL_OP",
    ">": "REL_OP",
    "!": "LOGICAL_OP",
    "=": "ASSIGN",
    "(": "LPAREN",
    ")": "RPAREN",
    "{": "LBRACE",
    "}": "RBRACE",
    ";": "SEMICOLON",
    ",": "COMMA",
}

DIGITS = "0123456789"
ESCAPES = {"n": "\n", "t": "\t", '"': '"', "\\": "\\"}


def string_value(lexeme):
    """Turn a string token like "Hi\\n" (with quotes) into its text: Hi + newline."""
    text, i = "", 1
    while i < len(lexeme) - 1:
        if lexeme[i] == "\\":
            text += ESCAPES[lexeme[i + 1]]
            i += 2
        else:
            text += lexeme[i]
            i += 1
    return text


def is_letter(ch):
    return ch.isascii() and (ch.isalpha() or ch == "_")


def is_word_char(ch):
    return ch.isascii() and (ch.isalnum() or ch == "_")


class Token:
    """A single lexical unit such as a keyword, identifier, number or operator."""

    def __init__(self, type_, value, line, column):
        self.type = type_
        self.value = value
        self.line = line
        self.column = column

    def to_dict(self):
        return {"type": self.type, "value": self.value, "line": self.line, "column": self.column}

    def __repr__(self):
        return f"Token({self.type}, {self.value!r}, {self.line}:{self.column})"


class Lexer:
    """Scans the source one character at a time and produces tokens."""

    def __init__(self, source):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens = []
        self.errors = []

    # ----- character helpers -------------------------------------------------

    def peek(self, offset=0):
        index = self.pos + offset
        return self.source[index] if index < len(self.source) else ""

    def advance(self):
        ch = self.source[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def add_token(self, type_, value, line, column):
        self.tokens.append(Token(type_, value, line, column))

    def add_error(self, message, line, column):
        self.errors.append(CompilerError(PHASE, message, line, column))

    # ----- main loop ---------------------------------------------------------

    def tokenize(self):
        """Scan the whole source. Returns (tokens, errors)."""
        while self.pos < len(self.source):
            ch = self.peek()
            if ch in " \t\r\n":
                self.advance()
            elif ch == "/" and self.peek(1) == "/":
                self.skip_comment()
            elif ch in DIGITS:
                self.read_number()
            elif is_letter(ch):
                self.read_word()
            elif ch == '"':
                self.read_string()
            else:
                self.read_operator()
        self.add_token("EOF", "", self.line, self.column)
        return self.tokens, self.errors

    def skip_comment(self):
        while self.pos < len(self.source) and self.peek() != "\n":
            self.advance()

    def read_number(self):
        line, column = self.line, self.column
        lexeme = ""
        while self.peek() and self.peek() in DIGITS:
            lexeme += self.advance()

        is_float = False
        if self.peek() == ".":
            lexeme += self.advance()
            if not (self.peek() and self.peek() in DIGITS):
                self.add_error(f"malformed number '{lexeme}' (expected digits after '.')", line, column)
                return
            is_float = True
            while self.peek() and self.peek() in DIGITS:
                lexeme += self.advance()

        # Something like "12abc" is neither a number nor an identifier.
        if self.peek() and is_word_char(self.peek()):
            while self.peek() and is_word_char(self.peek()):
                lexeme += self.advance()
            self.add_error(f"invalid number '{lexeme}' (identifiers cannot start with a digit)", line, column)
            return

        self.add_token("FLOAT_LITERAL" if is_float else "INT_LITERAL", lexeme, line, column)

    def read_word(self):
        line, column = self.line, self.column
        lexeme = ""
        while self.peek() and is_word_char(self.peek()):
            lexeme += self.advance()
        token_type = "KEYWORD" if lexeme in KEYWORDS else "IDENTIFIER"
        self.add_token(token_type, lexeme, line, column)

    def read_string(self):
        """Read "text in quotes". Supports the escapes \\n \\t \\" and \\\\."""
        line, column = self.line, self.column
        lexeme = self.advance()  # opening quote
        valid = True
        while True:
            ch = self.peek()
            if ch == "" or ch == "\n":
                self.add_error("unterminated string (missing closing '\"')", line, column)
                return
            lexeme += self.advance()
            if ch == '"':
                break
            if ch == "\\" and self.peek() not in ("", "\n"):
                escape = self.advance()
                lexeme += escape
                if escape not in ESCAPES:
                    self.add_error(f"unknown escape sequence '\\{escape}' in string", self.line, self.column - 2)
                    valid = False
        if valid:
            self.add_token("STRING_LITERAL", lexeme, line, column)

    def read_operator(self):
        line, column = self.line, self.column
        pair = self.peek() + self.peek(1)
        if pair in TWO_CHAR_OPERATORS:
            self.advance()
            self.advance()
            self.add_token(TWO_CHAR_OPERATORS[pair], pair, line, column)
            return

        ch = self.advance()
        if ch in ONE_CHAR_OPERATORS:
            self.add_token(ONE_CHAR_OPERATORS[ch], ch, line, column)
        elif ch in "&|":
            self.add_error(f"invalid character '{ch}' (did you mean '{ch * 2}'?)", line, column)
        else:
            shown = ch if ch.isprintable() else repr(ch)
            self.add_error(f"invalid character '{shown}'", line, column)


def tokenize(source):
    """Convenience wrapper: returns (tokens, errors) for the given source."""
    return Lexer(source).tokenize()
