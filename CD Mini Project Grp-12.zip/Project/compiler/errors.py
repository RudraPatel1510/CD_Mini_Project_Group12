"""Error and warning types shared by every compiler phase."""


class Diagnostic:
    """A message tied to a compiler phase and (optionally) a source position."""

    def __init__(self, phase, message, line=None, column=None):
        self.phase = phase
        self.message = message
        self.line = line
        self.column = column

    def __str__(self):
        if self.line is not None:
            return f"Line {self.line}: {self.message}"
        return self.message

    def to_dict(self):
        return {
            "phase": self.phase,
            "message": self.message,
            "line": self.line,
            "column": self.column,
            "text": str(self),
        }


class CompilerError(Diagnostic, Exception):
    """An error that stops compilation in the phase where it was found."""

    def __init__(self, phase, message, line=None, column=None):
        Diagnostic.__init__(self, phase, message, line, column)
        Exception.__init__(self, str(self))

    def __str__(self):
        return Diagnostic.__str__(self)


class CompilerWarning(Diagnostic):
    """A non-fatal problem; compilation continues."""
